---
title: "{{ replace .Name "-" " " | title }}"
id: "{{ lower .Name }}"
bgImage : "img/backgrounds/header-bg.webp"
bgImageAlt: "img/backgrounds/header-bg.jpg"
description: "{{ replace .Name "-" " " | title }} describes ... - meta"
date: {{ .Date }}
image: img/{{ lower .Name }}.jpg
tags: ["industrial", "personal", "pos", "fanless", "fanned"]
draft: false

---

Lorem ipsum dolor sit amet

