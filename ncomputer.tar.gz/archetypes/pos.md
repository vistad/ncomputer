---
title: "{{ upper .Name }}"
tags: ["POS", "моноблок", "терминал", "монитор", "сенсорный", "активное"]
draft: false

item1: {{ upper .Name }}

price1: ""
priceBefore: ""

imgs:
  - image: "img/pos/-1.webp"
    imalt: "img/pos/-1.jpg"
  - image: "img/pos/-2.webp"
    imalt: "img/pos/-2.jpg"
  - image: "img/pos/-3.webp"
    imalt: "img/pos/-3.jpg"
  - image: "img/pos/-4.webp"
    imalt: "img/pos/-4.jpg"
  - image: "img/pos/-5.webp"
    imalt: "img/pos/-5.jpg"
  - image: "img/pos/-6.webp"
    imalt: "img/pos/-6.jpg"
  - image: "img/pos/-7.webp"
    imalt: "img/pos/-7.jpg"

summary: {{ upper .Name }} - POS-терминал Windows. Высокая надежность, низкое потребление.

category: ["POS моноблок сенсорный"]
usage: ["Магазин", "Ресторан", "Кафе", "Школа", "Больница", "Склад"]
dispaly: ["15' LED дисплей категрии A 4:3 резистивный тачскрин"]
resolution: ["1024x768px"]
brightness: ["400 CD/m2"]
custdisplay: ["8' LED - Опционально"]
cpus: ["J1800", "J1900", "i3", "i5", "i7"]
ramtype: DDR3
ram: ["1x8Gb max 204 pin SO-DIMM"]
storage: ["1xmSATA", "1xSATA3.0 2.5'"]
video: ["1xVGA"]
ports: ["6xUSB2.0", "1xLAN RJ45", "1xCOM RS232", "2xPS/2", "1xLPT"]
wifi: ["Опционально"]
msr: ["Опционально"]
ibutton: ["Не поддерживается"]
audio: ["1x3.5мм Mic/2xLine"]
os: ["Windows 7", "Windows 10", "Linux"]
power: ["100-260VAC 50-60Hz - 12VDC/5A"]
poweron: ["Поддерживается"]
color: ["Черный"]
housing: ["Корпус - пластик, основание - пластик"]
packing: ["Ящик с поролоном 430x290x430mm"]
size: ["197x197x37мм"]
prodweight: ["7кг"]
brand: ["CJ Legend"]


specPackage:
  - 1 POS терминал
  - 1 сетевой адаптер
  - 1 сетевой провод с вилкой страны
  - 1 Руководство пользователя
  - 1 Гарантийный Талон
  - 1 CD с драйверами Windows
  - 2 WiFi антенны

orderConf: "Конфигурация заказа"
orderSum: "Ваш заказ"
agree2Terms: Согласитесь с условиями и положениями
---

* Высокая надежность
* Быстродействие
* Прочный пластиковый корпус
* Работа 24/365, низкотемпературный CPU
* Микро-компоненты, лёгкий вес, малое потребление
* Дополнительные SSD/HDD могут быть установлены
* Гарантия 2 года

