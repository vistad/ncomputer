---
title: "{{ upper .Name }}"
tags: ["промышленный", "пассивное", "безвентиляторный", "радиаторное"]
draft: false

item1: {{ upper .Name }}

price1: ""
priceBefore: ""

imgs:
  - image: "img/industrial/-1.webp"
    imalt: "img/industrial/-1.jpg"
  - image: "img/industrial/-2.webp"
    imalt: "img/industrial/-2.jpg"
  - image: "img/industrial/-3.webp"
    imalt: "img/industrial/-3.jpg"
  - image: "img/industrial/-4.webp"
    imalt: "img/industrial/-4.jpg"
  - image: "img/industrial/-5.webp"
    imalt: "img/industrial/-5.jpg"

summary: {{ upper .Name }} - промышленный NUC компьютер, POS, файловый/бекап сервер, NAS. Работа 24/365, надежность, низкое потребление.

categories: ["Промышленные компьютеры"]

usage: ["Магазин", "Ресторан", "Кафе", "Склад", "Производство"]

cpus: ["Intel Core i3-4005U @1.70GHz"]

cores: ["2-core 4-thread 3M cache"]

tdp: ["15W, average 8.7W, TDP-down 7.5W"]

ramtype: DDR3L

ram: ["1x8Gb max 204 pin SO-DIMM"]

storage: ["1xmSATA", "1xSATA3.0 2.5'", "1xM.2 2280 NVME"]

graphics: ["Intel HD Graphics 6000 integrated"]

video: ["1xHDMI 1xVGA Dual display"]

ports: ["2xUSB3.0", "4xUSB2.0", "2xLAN RJ45", "1xCOM"]

wifi: ["Wi-Fi 802.11n 2.4/5GHz Dual Band 2 antennas"]

nic: ["RTL 8168/8111/8112 Gigabit, PXE"]

audio: ["HD 1x3.5mm Mic/Line"]

cooling: ["Пассивное охлаждение"]

temperature: ["0~70 C"]

os: ["OS Windows 7", "Windows 8.1", "Windows 10", "Linux"]

power: ["DC 12V/5A External AC/DC adapter"]

poweron: ["Supported"]

size: ["197x197x37mm"]

prodweight: ["1.5kg"]

brand: ["Hystou"]


specPackage:
  - 1 NUC компьютер
  - 1 сетевой адаптер
  - 1 сетевой провод с вилкой страны
  - 1 SATA кабель + винты для дополнительного 2.5' диска
  - 1 Руководство пользователя
  - 1 Гарантийный Талон
  - 1 CD с драйверами Windows
  - 2 WiFi антенны
---

* Надежность промышленного класса
* Многозадачность, тяжелая нагрузка, быстродействие
* Алюминиевый корпус-радиатор
* 4K видео, HD аудио
* Работа 24/365 без обслуживания, низкотемпературный CPU
* Новейшие микро-компоненты, лёгкий вес, малое потребление
* Дополнительные SSD/HDD могут быть установлены
* Гарантия 3 года

