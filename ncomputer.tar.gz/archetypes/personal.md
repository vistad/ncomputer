---
title: "{{ upper .Name }}"
tags: ["персональный", "активное", "вентиляторный", "домашний", "офисный"]
draft: false

item1: {{ upper .Name }}

price1: ""
priceBefore: ""

imgs:
  - image: "img/personal/-1.webp"
    imalt: "img/personal/-1.jpg"
  - image: "img/personal/-2.webp"
    imalt: "img/personal/-2.jpg"
  - image: "img/personal/-3.webp"
    imalt: "img/personal/-3.jpg"
  - image: "img/personal/-4.webp"
    imalt: "img/personal/-4.jpg"
  - image: "img/personal/-5.webp"
    imalt: "img/personal/-5.jpg"

summary: {{ upper .Name }} - персональный NUC компьютер, рабочая станция, HTPC, файловый/бекап сервер, NAS. Работа 24/365, надежность, низкое потребление.

categories: ["Персональные компьютеры"]

usage: ["Дом", "Офис"]

cpus: ["Intel Core i3-4005U @1.70GHz"]

cores: ["2-core 4-thread 3M cache"]

tdp: ["45W"]

ramtype: DDR4

ram: ["2x32Gb max 260 pin SO-DIMM"]

storage: ["1xmSATA", "1xSATA3.0 2.5'", "1xM.2 2280 NVME"]

graphics: ["Intel HD Graphics 6000 integrated"]

video: ["1xHDMI 1xDP Dual 4K display"]

ports: ["4xUSB3.0", "2xUSB2.0", "1xTypeC USB3.1", "1xLAN RJ45"]

wifi: ["Wi-Fi 802.11n 2.4/5GHz Dual Band 2 antennas"]

bluetooth: ["Bluetooth 4.2"]

nic: ["RTL 8168/8111/8112 Gigabit, PXE"]

audio: ["HD 1x3.5mm Mic/Line"]

cooling: ["Активное охлаждение"]

temperature: ["0~70 C"]

os: ["OS Windows 7", "Windows 8.1", "Windows 10", "Linux"]

power: ["DC 19V/7A External AC/DC adapter"]

poweron: ["Supported"]

size: ["197x197x37mm"]

prodweight: ["1.8kg"]

brand: ["Hystou"]


specPackage:
  - 1 NUC компьютер
  - 1 сетевой адаптер
  - 1 сетевой провод с вилкой страны
  - 1 SATA кабель + винты для дополнительного 2.5' диска
  - 1 Руководство пользователя
  - 1 Гарантийный Талон
  - 1 CD с драйверами Windows
  - 2 WiFi антенны
---

* Надежность промышленного класса
* Многозадачность, тяжелая нагрузка, быстродействие
* Корпус - алюминий, пластик
* 4K видео, HD аудио
* Работа 24/365 без обслуживания, низкотемпературный CPU
* Новейшие микро-компоненты, лёгкий вес, малое потребление
* Дополнительные SSD/HDD могут быть установлены
* Гарантия 3 года

