$(function () { // Set up everything
	ShowItemPrices();
	$('#form1 select, #agree').change(MakeOrder);
	$('#print').click(MakeOrder);
	$('#deliverTo').change(function () {
		var el = $("#deliverTo option:selected");
		if (el.val()) {
			var country = el.text();
			$("#country").val(country);
		}
		else {
			$("#country").val("");
		}
		MakeOrder();
	});
	$("#us-date").text("Availability on " + FormatUS(new Date()) + ": In stock");
	$("#ru-date").text("По состоянию на " + FormatEU(new Date()) + ": в наличии");
});
function MakeOrder() {
	// Collect items:
	var subtotal = 0;
	var items = [];
	$('#form1 select.order').each(function () {
		var price = +$(this).val();
		if (price) {
			subtotal += price;
			var item = $(this).find("option:selected").text();
			items.push(item);
		}
	});
	// Build order:
	var shipping = +$("#deliverTo").val();
	var total = (subtotal + shipping).toFixed(2);
	var st = GetOrder(subtotal, shipping, total, items);
	st += GetAddress();
	$("#configtext").text(st);
	// Set payment link(s):
	$("input#paypal").attr("formaction", "https://paypal.me/VStadnichenko/" + total);
}
function GetOrder(subtotal, shipping, total, items) {
	if (total != 0) {
		let st = items.join("\n");
		st += "\nSubtotal: $" + subtotal.toFixed(2);
		st += "\nShipping cost: " + (shipping ? "$" + shipping : "");
		st += "\nOrder total: $" + total;
		st += "";
		st += "\nDate: " + FormatUS(new Date()) + "\n\n";
		return st;
	}
	else {
		return "";
	}
}
function GetAddress() {
	return $("#fname").val() + ' ' +
		$("#lname").val() + '\n' +
		$("#email").val() + '\n' +
		$("#tel").val() + '\n' +
		$("#address1").val() + '\n' +
		$("#city").val() + '\n' +
		$("#state").val() + ' ' +
		$("#zip").val() + '\n' +
		$("#country").val() + '\n';
}
function FormatUS(date) {
	var m = date.getMonth() + 1;
	var d = date.getDate();
	var y = date.getYear() + 1900;
	if (d < 10) d = "0" + d;
	if (m < 10) m = "0" + m;
	return m + "/" + d + "/" + y;
}
function FormatEU(date) {
	var m = date.getMonth() + 1;
	var d = date.getDate();
	var y = date.getYear() + 1900;
	if (d < 10) d = "0" + d;
	if (m < 10) m = "0" + m;
	return d + "." + m + "." + y;
}
function ShowItemPrices(selector) {
	$("select.order option", selector).each(function (i, el) {
		el = $(el);
		var v = el.val();
		if (v) {
			var st = el.text();
			el.text(st + " - $" + v);
		}
	});
}
