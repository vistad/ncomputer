---
title: "SFP-CEJ1900"
tags: ["промышленный", "пассивное", "безвентиляторный", "радиаторное"]
draft: false

item1: SFP-CEJ1900

price1: ""
priceBefore: ""

imgs:
  - image: "img/personal/sfp-1.webp"
    imalt: "img/personal/sfp-1.jpg"
  - image: "img/personal/sfp-2.webp"
    imalt: "img/personal/sfp-2.jpg"
  - image: "img/personal/sfp-3.webp"
    imalt: "img/personal/sfp-3.jpg"
  - image: "img/personal/sfp-4.webp"
    imalt: "img/personal/sfp-4.jpg"
  - image: "img/personal/sfp-5.webp"
    imalt: "img/personal/sfp-5.jpg"

summary: SFP-CEJ1900 - персональный NUC компьютер, бекап сервер, оптоволоконный шлюз. Работа 24/365, надежность, низкое потребление.

category: ["Промышленный компьютер"]

usage: ["Магазин", "Ресторан", "Кафе", "Склад", "Производство"]

cpus: ["Intel Celeron J-1900 @2.0GHz"]

cores: ["4-core 4-thread 2M cache"]

tdp: ["10W"]

ramtype: DDR3

ram: ["1x8Gb max 204 pin SO-DIMM"]

storage: ["1xmSATA", "1xSATA3.0 2.5'"]

graphics: ["Intel HD Graphics integrated"]

video: ["1xVGA"]

ports: ["1xUSB3.0", "1xUSB2.0", "2xLAN RJ45", "2xSFP", "1xCOM RJ45"]

nic: ["Intel 82583V, PXE"]

audio: ["-"]

cooling: ["Пассивное охлаждение"]

temperature: ["0~70 C"]

os: ["Windows 7", "Windows 10", "Linux"]

power: ["100-260VAC 50-60Hz - 12VDC/5A внешний блок питания"]

poweron: ["Поддерживается"]

size: ["197x197x37мм"]

prodweight: ["1.5кг"]

supplier: ["hystou"]


specPackage:
  - 1 NUC компьютер
  - 1 сетевой адаптер
  - 1 сетевой провод с вилкой страны
  - 1 SATA кабель + винты для 2.5' диска
  - 1 Руководство пользователя
  - 1 Гарантийный Талон
  - 1 CD с драйверами Windows
  - 2 WiFi антенны
---

* Надежность промышленного класса
* Многозадачность, тяжелая нагрузка, быстродействие
* Корпус - алюминий
* SFP порт для подключения оптического кабеля
* Работа 24/365, низкотемпературный CPU
* Новейшие компоненты, лёгкий вес, малое потребление
* Дополнительные SSD/HDD могут быть установлены
* Гарантия 3 года

